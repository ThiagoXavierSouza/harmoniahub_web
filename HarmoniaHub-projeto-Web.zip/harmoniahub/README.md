# HarmoniaHub — Aprenda · Toque · Evolua

Aplicação web de ensino musical (Java 17 + Spring Boot 3 + JPA/Hibernate + MySQL + Thymeleaf + Bootstrap 5).
O passo a passo para estudar e apresentar está no **Guia HarmoniaHub** (documento separado).

## Como rodar (resumo)

1. Instale **JDK 17+** e o **MySQL 8** (ou use o perfil H2 abaixo, sem MySQL).
2. Abra a pasta no **NetBeans** (File > Open Project) — ele já traz o Maven.
3. Ajuste `src/main/resources/application.properties` (usuário/senha do MySQL) ou defina `DB_PASSWORD`.
4. Execute (F6) ou, no terminal: `mvn spring-boot:run`
5. Acesse http://localhost:8080

Sem MySQL (banco em memória, só para testar):
`mvn spring-boot:run -Dspring-boot.run.profiles=h2`

## Usuários de teste (senha: 12345678)

| E-mail | Plano |
|---|---|
| juliana@harmoniahub.com.br | Premium (1.450 XP, 12 dias de sequência, 8 medalhas) |
| aluno@harmoniahub.com.br | Demo |
| mateus@harmoniahub.com.br / ana@harmoniahub.com.br | Premium (ranking) |

## Estrutura

```
src/main/java/br/com/harmoniahub
  config/      SecurityConfig (login, BCrypt, sessão única) · DataLoader (dados iniciais)
  model/       Entidades JPA: Usuario, TipoAcorde, Conquista, Tentativa, HistoricoXp + enums
  repository/  Interfaces Spring Data (consultas ao MySQL)
  service/     Regras de negócio: Usuario, Acorde, Escala, Treino, Gamificacao
  music/       Teoria musical em Java puro (acordes, escalas, campo harmônico) — testável sem Spring
  web/         Controllers que devolvem páginas HTML
  api/         Controller JSON do treino auditivo
  dto/         Formulários (CadastroForm, PerfilForm) com validação
src/main/resources
  templates/   Páginas Thymeleaf (login, cadastro, apresentacao, demo, painel, acordes, escalas, instrumentos, perfil)
  static/      css/harmonia.css · js/audio.js, instrumentos.js, treino.js · img/ (logos)
```

## Requisitos implementados

RF01 cadastro/login/perfil (CRUD) · RF02 dicionário de acordes · RF03 escalas e campo harmônico ·
RF04 treino auditivo · RF05 teclado virtual + Web MIDI · RF06 XP, streak, medalhas e ranking ·
RN001 parcial (travas Demo/Premium) · RN002 · RN003 · RN004 · RN005.
Fica para as próximas entregas: recuperação de senha, RN001 por nota mínima de 70%, JWT/HTTPS, contrabaixo/sopros/canto, painel do professor (UC008).
