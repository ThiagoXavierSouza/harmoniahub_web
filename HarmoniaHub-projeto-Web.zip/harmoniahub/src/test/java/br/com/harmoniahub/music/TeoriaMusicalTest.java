package br.com.harmoniahub.music;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.Test;

class TeoriaMusicalTest {

    @Test
    void campoHarmonicoDeDoMaior() {
        List<GrauHarmonico> campo = TeoriaMusical.campoHarmonico(0, ModoEscala.MAIOR);
        assertEquals("C", campo.get(0).cifraTriade());
        assertEquals("Dm7", campo.get(1).cifraTetrade());
        assertEquals("G7", campo.get(4).cifraTetrade());
        assertEquals("Bdim", campo.get(6).cifraTriade());
        assertEquals("vii°", campo.get(6).romano());
    }

    @Test
    void midisDaTriadeSobemAPartirDaTonica() {
        // Dm = D(62) F(65) A(69)
        assertEquals(List.of(62, 65, 69), TeoriaMusical.campoHarmonico(0, ModoEscala.MAIOR).get(1).midisTriade());
    }

    @Test
    void indiceENomeDeNotas() {
        assertEquals(6, TeoriaMusical.indiceNota("f#"));
        assertEquals("B", TeoriaMusical.nome(-1));
        assertEquals("Ré", TeoriaMusical.nomePt(14));
    }

    @Test
    void pentatonicaNaoTemCampoHarmonico() {
        assertEquals(List.of(), TeoriaMusical.campoHarmonico(0, ModoEscala.PENTATONICA_MAIOR));
    }
}
