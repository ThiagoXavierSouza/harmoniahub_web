package br.com.harmoniahub.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/** Entidade principal: tabela "usuarios" (RF01 / UC001). */
@Entity
@Table(name = "usuarios")
public class Usuario {

    public static final int XP_POR_NIVEL = 400;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nome;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    /** Guarda o HASH BCrypt, nunca a senha em texto puro. */
    @Column(nullable = false, length = 100)
    private String senha;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Plano plano = Plano.DEMO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private NivelConhecimento nivel = NivelConhecimento.INICIANTE;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "usuario_instrumentos", joinColumns = @JoinColumn(name = "usuario_id"))
    @Enumerated(EnumType.STRING)
    @Column(name = "instrumento", length = 20)
    private Set<Instrumento> instrumentos = new HashSet<>();

    private int xp;
    private int streak;
    private LocalDate ultimaPratica;

    @Column(nullable = false)
    private LocalDateTime criadoEm = LocalDateTime.now();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "usuario_conquistas",
            joinColumns = @JoinColumn(name = "usuario_id"),
            inverseJoinColumns = @JoinColumn(name = "conquista_id"))
    private Set<Conquista> conquistas = new HashSet<>();

    // ----- regras derivadas (não viram coluna) -----
    @Transient
    public boolean isPremium() { return plano == Plano.PREMIUM; }

    @Transient
    public int getNivelNumero() { return xp / XP_POR_NIVEL + 1; }

    @Transient
    public String getNivelRotulo() {
        int n = getNivelNumero();
        return n < 3 ? "Iniciante" : (n < 7 ? "Intermediário" : "Avançado");
    }

    /** Percentual (0-100) de progresso dentro do nível atual. */
    @Transient
    public int getProgressoNivel() { return (xp % XP_POR_NIVEL) * 100 / XP_POR_NIVEL; }

    @Transient
    public String getIniciais() {
        String[] p = nome.trim().split("\\s+");
        String s = p[0].substring(0, 1) + (p.length > 1 ? p[p.length - 1].substring(0, 1) : "");
        return s.toUpperCase();
    }

    // ----- getters e setters -----
    public Long getId() { return id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public Plano getPlano() { return plano; }
    public void setPlano(Plano plano) { this.plano = plano; }
    public NivelConhecimento getNivel() { return nivel; }
    public void setNivel(NivelConhecimento nivel) { this.nivel = nivel; }
    public Set<Instrumento> getInstrumentos() { return instrumentos; }
    public void setInstrumentos(Set<Instrumento> instrumentos) { this.instrumentos = instrumentos; }
    public int getXp() { return xp; }
    public void setXp(int xp) { this.xp = xp; }
    public int getStreak() { return streak; }
    public void setStreak(int streak) { this.streak = streak; }
    public LocalDate getUltimaPratica() { return ultimaPratica; }
    public void setUltimaPratica(LocalDate ultimaPratica) { this.ultimaPratica = ultimaPratica; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public Set<Conquista> getConquistas() { return conquistas; }
    public void setConquistas(Set<Conquista> conquistas) { this.conquistas = conquistas; }
}
