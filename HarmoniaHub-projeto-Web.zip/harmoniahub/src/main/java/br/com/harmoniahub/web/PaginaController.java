package br.com.harmoniahub.web;

import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.service.GamificacaoService;
import br.com.harmoniahub.service.TreinoService;
import java.security.Principal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Telas 2, 3 e 4 do protótipo: Apresentação, Demo e Painel Premium. */
@Controller
public class PaginaController {

    private final GamificacaoService gamificacao;

    public PaginaController(GamificacaoService gamificacao) {
        this.gamificacao = gamificacao;
    }

    @GetMapping("/")
    public String raiz(Principal principal) {
        return principal != null ? "redirect:/painel" : "redirect:/login";
    }

    @GetMapping("/apresentacao")
    public String apresentacao() { return "apresentacao"; }

    @GetMapping("/demo")
    public String demo() { return "demo"; }

    @GetMapping("/painel")
    public String painel(Model model) {
        Usuario u = (Usuario) model.getAttribute("usuarioLogado");
        // Quem não é Premium cai na vitrine Demo (a Tela 4 é exclusiva do plano pago)
        if (u == null || !u.isPremium()) return "redirect:/demo";

        model.addAttribute("ranking", gamificacao.rankingSemanal());
        model.addAttribute("todasConquistas", gamificacao.todasConquistas());
        model.addAttribute("perguntasPorRodada", TreinoService.PERGUNTAS_POR_RODADA);
        model.addAttribute("maxReproducoes", TreinoService.MAX_REPRODUCOES);
        return "painel";
    }
}
