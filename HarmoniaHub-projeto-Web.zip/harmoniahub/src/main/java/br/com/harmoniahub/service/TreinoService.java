package br.com.harmoniahub.service;

import br.com.harmoniahub.model.NivelConhecimento;
import br.com.harmoniahub.model.Tentativa;
import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.repository.TentativaRepository;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/**
 * Treino auditivo de intervalos (RF04 / UC005).
 * A rodada fica na HttpSession: se o usuário fechar o navegador no meio, ela se perde
 * e NENHUM XP é concedido (RN002). O limite de 3 audições por pergunta (RN004)
 * é contado no servidor, então não dá para burlar pelo navegador.
 */
@Service
public class TreinoService {

    public static final int PERGUNTAS_POR_RODADA = 5;
    public static final int MAX_REPRODUCOES = 3;      // RN004
    private static final String ATTR = "rodadaTreino";

    public record Opcao(int semitons, String rotulo) { }
    public record PerguntaDto(int numero, int total, List<Opcao> opcoes, int restantes) { }
    public record OuvirDto(List<Integer> notas, int restantes) { }
    public record RespostaDto(boolean acertou, String correta, boolean finalizada, GamificacaoService.Resumo resumo) { }

    private record Intervalo(int semitons, String rotulo) { }

    private static final List<Intervalo> BASICO = List.of(
            new Intervalo(4, "3ª Maior (4 Semitons)"),
            new Intervalo(7, "5ª Justa (7 Semitons)"),
            new Intervalo(12, "8ª Justa (12 Semitons)"),
            new Intervalo(5, "4ª Justa (5 Semitons)"));

    private static final List<Intervalo> COMPLETO = List.of(
            new Intervalo(2, "2ª Maior (2 Semitons)"),
            new Intervalo(3, "3ª Menor (3 Semitons)"),
            new Intervalo(4, "3ª Maior (4 Semitons)"),
            new Intervalo(5, "4ª Justa (5 Semitons)"),
            new Intervalo(7, "5ª Justa (7 Semitons)"),
            new Intervalo(9, "6ª Maior (9 Semitons)"),
            new Intervalo(10, "7ª Menor (10 Semitons)"),
            new Intervalo(12, "8ª Justa (12 Semitons)"));

    /** Estado de uma rodada. Serializable porque objetos de sessão podem ser persistidos. */
    private static class Questao implements Serializable {
        int raiz;
        int semitons;
        int[] opcoes;
        int reproducoes;
    }

    private static class Rodada implements Serializable {
        final List<Questao> questoes = new ArrayList<>();
        int atual;
        int acertos;
        boolean finalizada() { return atual >= questoes.size(); }
        Questao questaoAtual() { return questoes.get(atual); }
    }

    private final TentativaRepository tentativaRepo;
    private final GamificacaoService gamificacao;

    public TreinoService(TentativaRepository tentativaRepo, GamificacaoService gamificacao) {
        this.tentativaRepo = tentativaRepo;
        this.gamificacao = gamificacao;
    }

    public PerguntaDto iniciar(HttpSession sessao, Usuario u) {
        exigirPremium(u);
        List<Intervalo> pool = u.getNivel() == NivelConhecimento.INICIANTE ? BASICO : COMPLETO;
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        Rodada r = new Rodada();
        for (int i = 0; i < PERGUNTAS_POR_RODADA; i++) {
            Intervalo correto = pool.get(rnd.nextInt(pool.size()));
            List<Integer> opcoes = new ArrayList<>();
            opcoes.add(correto.semitons());
            List<Intervalo> embaralhado = new ArrayList<>(pool);
            Collections.shuffle(embaralhado);
            for (Intervalo it : embaralhado) {
                if (opcoes.size() == 4) break;
                if (it.semitons() != correto.semitons()) opcoes.add(it.semitons());
            }
            Collections.shuffle(opcoes);

            Questao q = new Questao();
            q.raiz = 55 + rnd.nextInt(12);                 // entre G3 e F#4
            q.semitons = correto.semitons();
            q.opcoes = opcoes.stream().mapToInt(Integer::intValue).toArray();
            r.questoes.add(q);
        }
        sessao.setAttribute(ATTR, r);
        return pergunta(sessao, u);
    }

    public PerguntaDto pergunta(HttpSession sessao, Usuario u) {
        exigirPremium(u);
        Rodada r = rodada(sessao);
        Questao q = r.questaoAtual();
        List<Opcao> opcoes = new ArrayList<>();
        for (int s : q.opcoes) opcoes.add(new Opcao(s, rotulo(s)));
        return new PerguntaDto(r.atual + 1, r.questoes.size(), opcoes, MAX_REPRODUCOES - q.reproducoes);
    }

    /** Devolve as notas a tocar e desconta uma reprodução (RN004). */
    public OuvirDto ouvir(HttpSession sessao, Usuario u) {
        exigirPremium(u);
        Questao q = rodada(sessao).questaoAtual();
        if (q.reproducoes >= MAX_REPRODUCOES) {
            throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS,
                    "Limite de " + MAX_REPRODUCOES + " reproduções atingido nesta pergunta (RN004).");
        }
        q.reproducoes++;
        return new OuvirDto(List.of(q.raiz, q.raiz + q.semitons), MAX_REPRODUCOES - q.reproducoes);
    }

    public RespostaDto responder(HttpSession sessao, Usuario u, int resposta) {
        exigirPremium(u);
        Rodada r = rodada(sessao);
        Questao q = r.questaoAtual();

        if (q.reproducoes == 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ouça o intervalo ao menos uma vez antes de responder.");
        }
        boolean valida = false;
        for (int s : q.opcoes) if (s == resposta) valida = true;
        if (!valida) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Opção inválida.");

        boolean acertou = resposta == q.semitons;
        tentativaRepo.save(new Tentativa(u, rotulo(q.semitons), rotulo(resposta), acertou));
        if (acertou) r.acertos++;
        r.atual++;

        if (r.finalizada()) {
            sessao.removeAttribute(ATTR);
            var resumo = gamificacao.registrarRodada(u.getId(), r.acertos, r.questoes.size());
            return new RespostaDto(acertou, rotulo(q.semitons), true, resumo);
        }
        return new RespostaDto(acertou, rotulo(q.semitons), false, null);
    }

    // ---------- auxiliares ----------
    private Rodada rodada(HttpSession sessao) {
        Object o = sessao.getAttribute(ATTR);
        if (o instanceof Rodada r && !r.finalizada()) return r;
        throw new ResponseStatusException(HttpStatus.CONFLICT, "Nenhuma rodada em andamento. Inicie uma nova rodada.");
    }

    private void exigirPremium(Usuario u) {
        if (!u.isPremium()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "O Treinamento Auditivo é exclusivo do plano Premium.");
        }
    }

    private static String rotulo(int semitons) {
        return COMPLETO.stream().filter(i -> i.semitons() == semitons).findFirst()
                .map(Intervalo::rotulo).orElse(semitons + " Semitons");
    }
}
