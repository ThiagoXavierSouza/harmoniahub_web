package br.com.harmoniahub.repository;

import br.com.harmoniahub.model.HistoricoXp;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface HistoricoXpRepository extends JpaRepository<HistoricoXp, Long> {

    /** Ranking semanal: soma o XP ganho desde :desde, do maior para o menor. */
    @Query("""
            select u.id as usuarioId, u.nome as nome, sum(h.pontos) as xp
            from HistoricoXp h join h.usuario u
            where h.data >= :desde
            group by u.id, u.nome
            order by sum(h.pontos) desc
            """)
    List<RankingLinha> ranking(@Param("desde") LocalDateTime desde, Pageable pageable);

    void deleteByUsuarioId(Long usuarioId);
}
