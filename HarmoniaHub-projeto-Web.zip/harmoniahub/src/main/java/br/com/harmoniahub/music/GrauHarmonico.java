package br.com.harmoniahub.music;

import java.util.List;

/** Um grau do campo harmônico: ex. "ii" -> Dm / Dm7. midisTriade = notas MIDI para tocar a tríade. */
public record GrauHarmonico(String romano, String cifraTriade, String cifraTetrade,
                            List<String> notasTriade, List<Integer> midisTriade) { }
