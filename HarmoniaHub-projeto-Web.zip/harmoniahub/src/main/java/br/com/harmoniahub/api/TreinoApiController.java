package br.com.harmoniahub.api;

import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.service.TreinoService;
import br.com.harmoniahub.service.TreinoService.*;
import br.com.harmoniahub.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import java.security.Principal;
import org.springframework.web.bind.annotation.*;

/** Endpoints JSON chamados pelo treino.js (fetch). */
@RestController
@RequestMapping("/api/treino")
public class TreinoApiController {

    public record RespostaRequest(int resposta) { }

    private final TreinoService treinoService;
    private final UsuarioService usuarioService;

    public TreinoApiController(TreinoService treinoService, UsuarioService usuarioService) {
        this.treinoService = treinoService;
        this.usuarioService = usuarioService;
    }

    private Usuario usuario(Principal p) {
        return usuarioService.buscarPorEmail(p.getName()).orElseThrow();
    }

    @PostMapping("/iniciar")
    public PerguntaDto iniciar(HttpSession s, Principal p) { return treinoService.iniciar(s, usuario(p)); }

    @GetMapping("/pergunta")
    public PerguntaDto pergunta(HttpSession s, Principal p) { return treinoService.pergunta(s, usuario(p)); }

    @PostMapping("/ouvir")
    public OuvirDto ouvir(HttpSession s, Principal p) { return treinoService.ouvir(s, usuario(p)); }

    @PostMapping("/responder")
    public RespostaDto responder(@RequestBody RespostaRequest req, HttpSession s, Principal p) {
        return treinoService.responder(s, usuario(p), req.resposta());
    }
}
