package br.com.harmoniahub.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Tipo de acorde (Maior, Menor, 7, maj7...). Guarda a "fórmula" em semitons
 * a partir da fundamental, ex.: "0,4,7" = Maior. (RF02)
 */
@Entity
@Table(name = "tipos_acorde")
public class TipoAcorde {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 40)
    private String nome;

    /** Sufixo da cifra: "" (maior), "m", "7", "maj7"... */
    @Column(nullable = false, length = 12)
    private String sufixo;

    @Column(nullable = false, length = 40)
    private String intervalos;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CategoriaAcorde categoria;

    /** true = só aparece para quem tem plano Premium. */
    @Column(nullable = false)
    private boolean premium;

    public TipoAcorde() { }

    public TipoAcorde(String nome, String sufixo, String intervalos, CategoriaAcorde categoria, boolean premium) {
        this.nome = nome; this.sufixo = sufixo; this.intervalos = intervalos;
        this.categoria = categoria; this.premium = premium;
    }

    @Transient
    public List<Integer> getSemitons() {
        List<Integer> r = new ArrayList<>();
        for (String s : intervalos.split(",")) r.add(Integer.parseInt(s.trim()));
        return r;
    }

    /** Texto do combo da tela: "Menor (m) — Tríade". */
    @Transient
    public String getRotuloCompleto() {
        return nome + (sufixo.isEmpty() ? "" : " (" + sufixo + ")") + " — " + categoria.getRotulo();
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getSufixo() { return sufixo; }
    public void setSufixo(String sufixo) { this.sufixo = sufixo; }
    public String getIntervalos() { return intervalos; }
    public void setIntervalos(String intervalos) { this.intervalos = intervalos; }
    public CategoriaAcorde getCategoria() { return categoria; }
    public void setCategoria(CategoriaAcorde categoria) { this.categoria = categoria; }
    public boolean isPremium() { return premium; }
    public void setPremium(boolean premium) { this.premium = premium; }
}
