package br.com.harmoniahub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Ponto de entrada: inicia o Spring Boot (Tomcat embutido na porta 8080). */
@SpringBootApplication
public class HarmoniaHubApplication {
    public static void main(String[] args) {
        SpringApplication.run(HarmoniaHubApplication.class, args);
    }
}
