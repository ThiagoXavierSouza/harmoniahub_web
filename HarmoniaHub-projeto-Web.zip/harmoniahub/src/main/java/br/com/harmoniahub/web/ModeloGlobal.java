package br.com.harmoniahub.web;

import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.service.UsuarioService;
import java.security.Principal;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

/** Coloca "usuarioLogado" em TODAS as páginas (usado no menu e nas travas de plano). */
@ControllerAdvice(basePackages = "br.com.harmoniahub.web")
public class ModeloGlobal {

    private final UsuarioService usuarioService;

    public ModeloGlobal(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @ModelAttribute("usuarioLogado")
    public Usuario usuarioLogado(Principal principal) {
        return principal == null ? null : usuarioService.buscarPorEmail(principal.getName()).orElse(null);
    }
}
