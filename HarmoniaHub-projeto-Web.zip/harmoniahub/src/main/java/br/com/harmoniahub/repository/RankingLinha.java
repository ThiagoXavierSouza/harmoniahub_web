package br.com.harmoniahub.repository;

/** Projeção: o Spring preenche os getters a partir dos apelidos (alias) do JPQL. */
public interface RankingLinha {
    Long getUsuarioId();
    String getNome();
    Long getXp();
}
