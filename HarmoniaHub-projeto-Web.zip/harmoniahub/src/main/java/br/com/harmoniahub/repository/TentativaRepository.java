package br.com.harmoniahub.repository;

import br.com.harmoniahub.model.Tentativa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TentativaRepository extends JpaRepository<Tentativa, Long> {
    long countByUsuarioIdAndAcertouTrue(Long usuarioId);
    void deleteByUsuarioId(Long usuarioId);
}
