package br.com.harmoniahub.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** Histórico de acertos/erros do treino auditivo (RF04 / RF06). */
@Entity
@Table(name = "tentativas")
public class Tentativa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @Column(nullable = false, length = 60)
    private String intervaloCorreto;

    @Column(nullable = false, length = 60)
    private String respostaDada;

    private boolean acertou;

    @Column(nullable = false)
    private LocalDateTime dataHora = LocalDateTime.now();

    public Tentativa() { }

    public Tentativa(Usuario usuario, String intervaloCorreto, String respostaDada, boolean acertou) {
        this.usuario = usuario; this.intervaloCorreto = intervaloCorreto;
        this.respostaDada = respostaDada; this.acertou = acertou;
    }

    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public String getIntervaloCorreto() { return intervaloCorreto; }
    public String getRespostaDada() { return respostaDada; }
    public boolean isAcertou() { return acertou; }
    public LocalDateTime getDataHora() { return dataHora; }
}
