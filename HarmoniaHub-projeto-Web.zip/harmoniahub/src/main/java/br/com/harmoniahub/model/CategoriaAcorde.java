package br.com.harmoniahub.model;

public enum CategoriaAcorde {
    TRIADE("Tríade"), TETRADE("Tétrade"), EXTENSAO("Extensão");

    private final String rotulo;
    CategoriaAcorde(String rotulo) { this.rotulo = rotulo; }
    public String getRotulo() { return rotulo; }
}
