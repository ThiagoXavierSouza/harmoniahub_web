package br.com.harmoniahub.dto;

import br.com.harmoniahub.model.Instrumento;
import br.com.harmoniahub.model.NivelConhecimento;
import br.com.harmoniahub.model.Usuario;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

/** Edição de perfil: nome, nível e instrumentos de interesse (RF01). */
public class PerfilForm {

    @NotBlank(message = "Informe seu nome")
    @Size(min = 3, max = 100, message = "O nome deve ter de 3 a 100 caracteres")
    private String nome;

    private NivelConhecimento nivel;
    private Set<Instrumento> instrumentos = new HashSet<>();

    public static PerfilForm de(Usuario u) {
        PerfilForm f = new PerfilForm();
        f.nome = u.getNome();
        f.nivel = u.getNivel();
        f.instrumentos = new HashSet<>(u.getInstrumentos());
        return f;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public NivelConhecimento getNivel() { return nivel; }
    public void setNivel(NivelConhecimento nivel) { this.nivel = nivel; }
    public Set<Instrumento> getInstrumentos() { return instrumentos; }
    public void setInstrumentos(Set<Instrumento> instrumentos) { this.instrumentos = instrumentos; }
}
