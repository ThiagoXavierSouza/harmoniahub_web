package br.com.harmoniahub.model;

import jakarta.persistence.*;
import java.util.Objects;

/** Medalha virtual (RF06). Ex.: "Semana Afinada" ao atingir 7 dias seguidos. */
@Entity
@Table(name = "conquistas")
public class Conquista {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 40)
    private String codigo;

    @Column(nullable = false, length = 60)
    private String nome;

    @Column(nullable = false, length = 160)
    private String descricao;

    /** Classe do Bootstrap Icons, ex.: "bi-fire" */
    @Column(nullable = false, length = 40)
    private String icone;

    public Conquista() { }

    public Conquista(String codigo, String nome, String descricao, String icone) {
        this.codigo = codigo; this.nome = nome; this.descricao = descricao; this.icone = icone;
    }

    public Long getId() { return id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getIcone() { return icone; }
    public void setIcone(String icone) { this.icone = icone; }

    // equals/hashCode pelo código: necessário para usar Conquista dentro de um Set
    @Override public boolean equals(Object o) {
        return this == o || (o instanceof Conquista c && Objects.equals(codigo, c.codigo));
    }
    @Override public int hashCode() { return Objects.hash(codigo); }
}
