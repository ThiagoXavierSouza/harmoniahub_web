package br.com.harmoniahub.dto;

import br.com.harmoniahub.model.Instrumento;
import br.com.harmoniahub.model.NivelConhecimento;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

/** Objeto que recebe os campos do formulário de cadastro (com validação). */
public class CadastroForm {

    @NotBlank(message = "Informe seu nome")
    @Size(min = 3, max = 100, message = "O nome deve ter de 3 a 100 caracteres")
    private String nome;

    @NotBlank(message = "Informe seu e-mail")
    @Email(message = "E-mail inválido")
    @Size(max = 150)
    private String email;

    @NotBlank(message = "Informe uma senha")
    @Size(min = 8, max = 60, message = "A senha deve ter de 8 a 60 caracteres")
    private String senha;

    @NotBlank(message = "Confirme a senha")
    private String confirmarSenha;

    private NivelConhecimento nivel = NivelConhecimento.INICIANTE;
    private Set<Instrumento> instrumentos = new HashSet<>();

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public String getConfirmarSenha() { return confirmarSenha; }
    public void setConfirmarSenha(String confirmarSenha) { this.confirmarSenha = confirmarSenha; }
    public NivelConhecimento getNivel() { return nivel; }
    public void setNivel(NivelConhecimento nivel) { this.nivel = nivel; }
    public Set<Instrumento> getInstrumentos() { return instrumentos; }
    public void setInstrumentos(Set<Instrumento> instrumentos) { this.instrumentos = instrumentos; }
}
