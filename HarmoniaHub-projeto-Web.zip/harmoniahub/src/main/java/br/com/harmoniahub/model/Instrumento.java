package br.com.harmoniahub.model;

public enum Instrumento {
    VIOLAO("Violão"), TECLADO("Teclado"), CONTRABAIXO("Contrabaixo"), SOPROS("Sopros"), CANTO("Canto");

    private final String rotulo;
    Instrumento(String rotulo) { this.rotulo = rotulo; }
    public String getRotulo() { return rotulo; }
}
