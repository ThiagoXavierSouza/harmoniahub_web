package br.com.harmoniahub.web;

import br.com.harmoniahub.model.TipoAcorde;
import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.music.TeoriaMusical;
import br.com.harmoniahub.service.AcordeService;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Dicionário e formador de acordes: consulta por fundamental + tipo (RF02 / UC003). */
@Controller
public class AcordeController {

    private final AcordeService acordeService;

    public AcordeController(AcordeService acordeService) {
        this.acordeService = acordeService;
    }

    @GetMapping("/acordes")
    public String acordes(@RequestParam(defaultValue = "C") String raiz,
                          @RequestParam(required = false) Long tipoId, Model model) {
        Usuario u = (Usuario) model.getAttribute("usuarioLogado");

        String raizOk = acordeService.raizValida(raiz);
        List<TipoAcorde> tipos = acordeService.tiposDisponiveis(u);
        TipoAcorde selecionado = tipos.stream()
                .filter(t -> t.getId().equals(tipoId)).findFirst().orElse(tipos.get(0));

        model.addAttribute("raizes", TeoriaMusical.NOTAS);
        model.addAttribute("raizSel", raizOk);
        model.addAttribute("tipos", tipos);
        model.addAttribute("tipoSel", selecionado);
        model.addAttribute("bloqueados", acordeService.tiposBloqueados(u));
        model.addAttribute("resultado", acordeService.formar(raizOk, selecionado));
        model.addAttribute("catalogo", acordeService.catalogo(raizOk, tipos));
        return "acordes";
    }
}
