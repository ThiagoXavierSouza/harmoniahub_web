package br.com.harmoniahub.music;

/**
 * Escalas e modos suportados (RF03). Cada modo é definido pelos
 * semitons a partir da tônica. Não depende de Spring: é Java puro.
 */
public enum ModoEscala {

    MAIOR("Maior (Jônio)", new int[]{0, 2, 4, 5, 7, 9, 11}, false),
    MENOR_NATURAL("Menor natural (Eólio)", new int[]{0, 2, 3, 5, 7, 8, 10}, false),
    DORICO("Dórico", new int[]{0, 2, 3, 5, 7, 9, 10}, true),
    FRIGIO("Frígio", new int[]{0, 1, 3, 5, 7, 8, 10}, true),
    LIDIO("Lídio", new int[]{0, 2, 4, 6, 7, 9, 11}, true),
    MIXOLIDIO("Mixolídio", new int[]{0, 2, 4, 5, 7, 9, 10}, true),
    LOCRIO("Lócrio", new int[]{0, 1, 3, 5, 6, 8, 10}, true),
    MENOR_HARMONICA("Menor harmônica", new int[]{0, 2, 3, 5, 7, 8, 11}, true),
    PENTATONICA_MAIOR("Pentatônica maior", new int[]{0, 2, 4, 7, 9}, true),
    PENTATONICA_MENOR("Pentatônica menor", new int[]{0, 3, 5, 7, 10}, true);

    private final String rotulo;
    private final int[] semitons;
    private final boolean premium;

    ModoEscala(String rotulo, int[] semitons, boolean premium) {
        this.rotulo = rotulo;
        this.semitons = semitons;
        this.premium = premium;
    }

    public String getRotulo() { return rotulo; }
    public int[] getSemitons() { return semitons.clone(); }
    public boolean isPremium() { return premium; }

    /** Só escalas de 7 notas formam campo harmônico por sobreposição de terças. */
    public boolean isHeptatonico() { return semitons.length == 7; }
}
