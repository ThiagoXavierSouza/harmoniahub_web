package br.com.harmoniahub.config;

import br.com.harmoniahub.service.UsuarioService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.session.HttpSessionEventPublisher;

/** Quem pode acessar o quê, como é o login e a regra de sessão única (RN003). */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /** Avisa o Spring quando uma sessão HTTP termina (necessário p/ contar sessões por usuário). */
    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, UsuarioService usuarioService) throws Exception {
        http
            .authorizeHttpRequests(a -> a
                .requestMatchers("/", "/login", "/cadastro", "/apresentacao", "/demo",
                                 "/css/**", "/js/**", "/img/**", "/error").permitAll()
                .anyRequest().authenticated())
            .formLogin(f -> f
                .loginPage("/login")
                .usernameParameter("email")
                .passwordParameter("senha")
                .defaultSuccessUrl("/painel", true)
                .failureUrl("/login?erro")
                .permitAll())
            .rememberMe(r -> r
                .key("harmoniahub-chave-lembrar")
                .rememberMeParameter("lembrar")
                .userDetailsService(usuarioService)
                .tokenValiditySeconds(14 * 24 * 60 * 60))
            .logout(l -> l
                .logoutSuccessUrl("/login?saiu")
                .permitAll())
            // RN003: uma única sessão ativa por conta. Novo login derruba o anterior.
            .sessionManagement(s -> s
                .maximumSessions(1)
                .expiredUrl("/login?expirada"));
        return http.build();
    }
}
