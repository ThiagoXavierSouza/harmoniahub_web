package br.com.harmoniahub.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/** Teclado virtual com Web Audio e Web MIDI (RF05 / UC006 / UC009). */
@Controller
public class InstrumentoController {
    @GetMapping("/instrumentos")
    public String instrumentos() { return "instrumentos"; }
}
