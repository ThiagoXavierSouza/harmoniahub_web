package br.com.harmoniahub.music;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Regras de teoria musical usadas pelo dicionário de acordes (RF02)
 * e pelo visualizador de escalas (RF03).
 * Convenção: 0 = Dó (C), 1 = Dó#, ... 11 = Si (B). MIDI 60 = Dó central (C4).
 */
public final class TeoriaMusical {

    public static final String[] NOTAS = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    public static final String[] NOTAS_PT = {"Dó", "Dó#", "Ré", "Ré#", "Mi", "Fá", "Fá#", "Sol", "Sol#", "Lá", "Lá#", "Si"};

    private static final Map<Integer, String> INTERVALOS = Map.ofEntries(
            Map.entry(0, "Fundamental"), Map.entry(1, "2ª menor"), Map.entry(2, "2ª maior"),
            Map.entry(3, "3ª menor"), Map.entry(4, "3ª maior"), Map.entry(5, "4ª justa"),
            Map.entry(6, "5ª diminuta"), Map.entry(7, "5ª justa"), Map.entry(8, "5ª aumentada"),
            Map.entry(9, "6ª maior (7ª dim.)"), Map.entry(10, "7ª menor"), Map.entry(11, "7ª maior"),
            Map.entry(12, "8ª justa"), Map.entry(14, "9ª maior"));

    private static final String[] ROMANOS = {"I", "II", "III", "IV", "V", "VI", "VII"};

    private TeoriaMusical() { }

    /** Índice 0..11 de uma nota como "C#" (aceita minúsculas). */
    public static int indiceNota(String nota) {
        for (int i = 0; i < NOTAS.length; i++) {
            if (NOTAS[i].equalsIgnoreCase(nota)) return i;
        }
        throw new IllegalArgumentException("Nota inválida: " + nota);
    }

    public static String nome(int semitons) { return NOTAS[Math.floorMod(semitons, 12)]; }

    public static String nomePt(int semitons) { return NOTAS_PT[Math.floorMod(semitons, 12)]; }

    public static String rotuloIntervalo(int semitons) {
        return INTERVALOS.getOrDefault(semitons, semitons + " semitons");
    }

    /** MIDI da tônica na oitava central (C4 = 60). */
    public static int midiBase(int indiceRaiz) { return 60 + indiceRaiz; }

    // ---------- Escalas ----------

    public static List<Integer> semitonsDaEscala(int raiz, ModoEscala modo) {
        List<Integer> r = new ArrayList<>();
        for (int s : modo.getSemitons()) r.add(raiz + s);
        return r;
    }

    // ---------- Campo harmônico ----------

    public static List<GrauHarmonico> campoHarmonico(int raiz, ModoEscala modo) {
        if (!modo.isHeptatonico()) return List.of();
        int[] e = modo.getSemitons();
        List<GrauHarmonico> campo = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            int tonica = e[i];
            int terca = dist(tonica, e[(i + 2) % 7]);
            int quinta = dist(tonica, e[(i + 4) % 7]);
            int setima = dist(tonica, e[(i + 6) % 7]);

            String sufTriade = sufixoTriade(terca, quinta);
            String sufTetrade = sufixoTetrade(terca, quinta, setima);
            String nomeRaiz = nome(raiz + tonica);

            int midiTonica = midiBase(Math.floorMod(raiz + tonica, 12));
            campo.add(new GrauHarmonico(
                    romano(i, sufTriade),
                    nomeRaiz + sufTriade,
                    nomeRaiz + sufTetrade,
                    List.of(nomeRaiz, nome(raiz + e[(i + 2) % 7]), nome(raiz + e[(i + 4) % 7])),
                    List.of(midiTonica, midiTonica + terca, midiTonica + quinta)));
        }
        return campo;
    }

    private static int dist(int de, int para) { return Math.floorMod(para - de, 12); }

    static String sufixoTriade(int terca, int quinta) {
        if (terca == 4 && quinta == 7) return "";
        if (terca == 3 && quinta == 7) return "m";
        if (terca == 3 && quinta == 6) return "dim";
        if (terca == 4 && quinta == 8) return "aug";
        return "?";
    }

    static String sufixoTetrade(int terca, int quinta, int setima) {
        if (terca == 4 && quinta == 7 && setima == 11) return "maj7";
        if (terca == 4 && quinta == 7 && setima == 10) return "7";
        if (terca == 3 && quinta == 7 && setima == 10) return "m7";
        if (terca == 3 && quinta == 6 && setima == 10) return "m7(b5)";
        if (terca == 3 && quinta == 6 && setima == 9) return "dim7";
        if (terca == 3 && quinta == 7 && setima == 11) return "m(maj7)";
        if (terca == 4 && quinta == 8 && setima == 11) return "maj7(#5)";
        return "?";
    }

    private static String romano(int grau, String sufixoTriade) {
        String r = ROMANOS[grau];
        return switch (sufixoTriade) {
            case "m" -> r.toLowerCase();
            case "dim" -> r.toLowerCase() + "°";
            case "aug" -> r + "+";
            default -> r;
        };
    }
}
