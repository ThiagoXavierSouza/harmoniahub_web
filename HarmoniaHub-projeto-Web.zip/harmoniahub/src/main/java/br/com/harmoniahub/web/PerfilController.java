package br.com.harmoniahub.web;

import br.com.harmoniahub.dto.PerfilForm;
import br.com.harmoniahub.model.Instrumento;
import br.com.harmoniahub.model.NivelConhecimento;
import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.service.UsuarioService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import java.security.Principal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

/** Ver, editar e excluir a própria conta (RF01 / UC001). */
@Controller
public class PerfilController {

    private final UsuarioService usuarioService;

    public PerfilController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @ModelAttribute("niveis")
    public NivelConhecimento[] niveis() { return NivelConhecimento.values(); }

    @ModelAttribute("instrumentosDisponiveis")
    public Instrumento[] instrumentos() { return Instrumento.values(); }

    @GetMapping("/perfil")
    public String perfil(Model model) {
        Usuario u = (Usuario) model.getAttribute("usuarioLogado");
        model.addAttribute("form", PerfilForm.de(u));
        return "perfil";
    }

    @PostMapping("/perfil")
    public String atualizar(@Valid @ModelAttribute("form") PerfilForm form, BindingResult result,
                            Principal principal) {
        if (result.hasErrors()) return "perfil";
        usuarioService.atualizarPerfil(principal.getName(), form);
        return "redirect:/perfil?salvo";
    }

    @PostMapping("/perfil/excluir")
    public String excluir(Principal principal, HttpServletRequest request) throws ServletException {
        usuarioService.excluir(principal.getName());
        request.logout();                       // encerra a sessão do usuário apagado
        return "redirect:/login?excluida";
    }
}
