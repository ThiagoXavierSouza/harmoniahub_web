package br.com.harmoniahub.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** Cada ganho de XP vira uma linha; a soma dos últimos 7 dias gera o ranking semanal. */
@Entity
@Table(name = "historico_xp")
public class HistoricoXp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    private int pontos;

    @Column(nullable = false, length = 40)
    private String origem;

    @Column(nullable = false)
    private LocalDateTime data = LocalDateTime.now();

    public HistoricoXp() { }

    public HistoricoXp(Usuario usuario, int pontos, String origem) {
        this.usuario = usuario; this.pontos = pontos; this.origem = origem;
    }

    public HistoricoXp(Usuario usuario, int pontos, String origem, LocalDateTime data) {
        this(usuario, pontos, origem);
        this.data = data;
    }

    public Long getId() { return id; }
    public Usuario getUsuario() { return usuario; }
    public int getPontos() { return pontos; }
    public String getOrigem() { return origem; }
    public LocalDateTime getData() { return data; }
}
