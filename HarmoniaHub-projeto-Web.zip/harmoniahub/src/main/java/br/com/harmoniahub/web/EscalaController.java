package br.com.harmoniahub.web;

import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.music.ModoEscala;
import br.com.harmoniahub.music.TeoriaMusical;
import br.com.harmoniahub.service.AcordeService;
import br.com.harmoniahub.service.EscalaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Escalas, modos e campo harmônico no braço do violão e no teclado (RF03 / UC004). */
@Controller
public class EscalaController {

    private final EscalaService escalaService;
    private final AcordeService acordeService;

    public EscalaController(EscalaService escalaService, AcordeService acordeService) {
        this.escalaService = escalaService;
        this.acordeService = acordeService;
    }

    @GetMapping("/escalas")
    public String escalas(@RequestParam(defaultValue = "C") String raiz,
                          @RequestParam(defaultValue = "MAIOR") String modo, Model model) {
        Usuario u = (Usuario) model.getAttribute("usuarioLogado");
        String raizOk = acordeService.raizValida(raiz);
        ModoEscala modoOk = escalaService.modoValido(modo, u);

        model.addAttribute("raizes", TeoriaMusical.NOTAS);
        model.addAttribute("raizSel", raizOk);
        model.addAttribute("modoSel", modoOk);
        model.addAttribute("modos", escalaService.modosDisponiveis(u));
        model.addAttribute("modosBloqueados", java.util.Arrays.stream(ModoEscala.values())
                .filter(m -> m.isPremium() && !u.isPremium()).toList());
        model.addAttribute("escala", escalaService.montar(raizOk, modoOk));
        return "escalas";
    }
}
