package br.com.harmoniahub.service;

import br.com.harmoniahub.dto.CadastroForm;
import br.com.harmoniahub.dto.PerfilForm;
import br.com.harmoniahub.model.Plano;
import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.repository.HistoricoXpRepository;
import br.com.harmoniahub.repository.TentativaRepository;
import br.com.harmoniahub.repository.UsuarioRepository;
import java.util.HashSet;
import java.util.Optional;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Regras de negócio de usuário (CRUD) + integração com o login do Spring Security.
 * UserDetailsService: o Spring chama loadUserByUsername() quando alguém tenta logar.
 */
@Service
public class UsuarioService implements UserDetailsService {

    private final UsuarioRepository usuarioRepo;
    private final TentativaRepository tentativaRepo;
    private final HistoricoXpRepository xpRepo;
    private final PasswordEncoder encoder;

    public UsuarioService(UsuarioRepository usuarioRepo, TentativaRepository tentativaRepo,
                          HistoricoXpRepository xpRepo, PasswordEncoder encoder) {
        this.usuarioRepo = usuarioRepo;
        this.tentativaRepo = tentativaRepo;
        this.xpRepo = xpRepo;
        this.encoder = encoder;
    }

    // ---------- Login ----------
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Usuario u = usuarioRepo.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
        return User.withUsername(u.getEmail()).password(u.getSenha()).roles("USER").build();
    }

    // ---------- CREATE ----------
    @Transactional
    public Usuario cadastrar(CadastroForm f) {
        String email = f.getEmail().trim().toLowerCase();
        if (usuarioRepo.existsByEmailIgnoreCase(email)) {
            throw new EmailJaCadastradoException(email);
        }
        Usuario u = new Usuario();
        u.setNome(f.getNome().trim());
        u.setEmail(email);
        u.setSenha(encoder.encode(f.getSenha()));   // BCrypt
        u.setNivel(f.getNivel());
        u.setInstrumentos(new HashSet<>(f.getInstrumentos()));
        return usuarioRepo.save(u);
    }

    // ---------- READ ----------
    @Transactional(readOnly = true)
    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepo.findByEmailIgnoreCase(email);
    }

    // ---------- UPDATE ----------
    @Transactional
    public Usuario atualizarPerfil(String email, PerfilForm f) {
        Usuario u = usuarioRepo.findByEmailIgnoreCase(email).orElseThrow();
        u.setNome(f.getNome().trim());
        u.setNivel(f.getNivel());
        u.setInstrumentos(new HashSet<>(f.getInstrumentos()));
        return usuarioRepo.save(u);
    }

    /** Simula a assinatura: em um sistema real aqui entraria o gateway de pagamento. */
    @Transactional
    public void alterarPlano(String email, Plano plano) {
        Usuario u = usuarioRepo.findByEmailIgnoreCase(email).orElseThrow();
        u.setPlano(plano);
        usuarioRepo.save(u);
    }

    // ---------- DELETE ----------
    @Transactional
    public void excluir(String email) {
        Usuario u = usuarioRepo.findByEmailIgnoreCase(email).orElseThrow();
        tentativaRepo.deleteByUsuarioId(u.getId());   // filhos primeiro (chave estrangeira)
        xpRepo.deleteByUsuarioId(u.getId());
        usuarioRepo.delete(u);
    }
}
