package br.com.harmoniahub.repository;

import br.com.harmoniahub.model.Usuario;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/** O Spring Data cria a implementação sozinho a partir do NOME dos métodos. */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);
}
