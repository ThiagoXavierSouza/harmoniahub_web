package br.com.harmoniahub.config;

import br.com.harmoniahub.model.*;
import br.com.harmoniahub.repository.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Roda uma vez ao iniciar e popula tabelas vazias: tipos de acorde, medalhas e
 * usuários de demonstração (os mesmos nomes do protótipo da documentação).
 */
@Component
public class DataLoader implements CommandLineRunner {

    private final TipoAcordeRepository tipoRepo;
    private final ConquistaRepository conquistaRepo;
    private final UsuarioRepository usuarioRepo;
    private final HistoricoXpRepository xpRepo;
    private final PasswordEncoder encoder;
    private final boolean seed;

    public DataLoader(TipoAcordeRepository tipoRepo, ConquistaRepository conquistaRepo,
                      UsuarioRepository usuarioRepo, HistoricoXpRepository xpRepo,
                      PasswordEncoder encoder, @Value("${harmonia.seed:true}") boolean seed) {
        this.tipoRepo = tipoRepo; this.conquistaRepo = conquistaRepo; this.usuarioRepo = usuarioRepo;
        this.xpRepo = xpRepo; this.encoder = encoder; this.seed = seed;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (!seed) return;
        if (tipoRepo.count() == 0) criarTiposDeAcorde();
        if (conquistaRepo.count() == 0) criarConquistas();
        if (usuarioRepo.count() == 0) criarUsuariosDemo();
    }

    private void criarTiposDeAcorde() {
        tipoRepo.saveAll(List.of(
            new TipoAcorde("Maior", "", "0,4,7", CategoriaAcorde.TRIADE, false),
            new TipoAcorde("Menor", "m", "0,3,7", CategoriaAcorde.TRIADE, false),
            new TipoAcorde("Diminuto", "dim", "0,3,6", CategoriaAcorde.TRIADE, false),
            new TipoAcorde("Aumentado", "aug", "0,4,8", CategoriaAcorde.TRIADE, false),
            new TipoAcorde("Sétima dominante", "7", "0,4,7,10", CategoriaAcorde.TETRADE, true),
            new TipoAcorde("Sétima maior", "maj7", "0,4,7,11", CategoriaAcorde.TETRADE, true),
            new TipoAcorde("Menor com sétima", "m7", "0,3,7,10", CategoriaAcorde.TETRADE, true),
            new TipoAcorde("Meio-diminuto", "m7(b5)", "0,3,6,10", CategoriaAcorde.TETRADE, true),
            new TipoAcorde("Diminuto com sétima", "dim7", "0,3,6,9", CategoriaAcorde.TETRADE, true),
            new TipoAcorde("Com sexta", "6", "0,4,7,9", CategoriaAcorde.TETRADE, true),
            new TipoAcorde("Suspenso 4", "sus4", "0,5,7", CategoriaAcorde.EXTENSAO, true),
            new TipoAcorde("Suspenso 2", "sus2", "0,2,7", CategoriaAcorde.EXTENSAO, true),
            new TipoAcorde("Nona dominante", "9", "0,4,7,10,14", CategoriaAcorde.EXTENSAO, true),
            new TipoAcorde("Nona maior", "maj9", "0,4,7,11,14", CategoriaAcorde.EXTENSAO, true),
            new TipoAcorde("Menor com nona", "m9", "0,3,7,10,14", CategoriaAcorde.EXTENSAO, true)));
    }

    private void criarConquistas() {
        conquistaRepo.saveAll(List.of(
            new Conquista("PRIMEIRA_RODADA", "Primeira Rodada", "Concluiu seu primeiro treino auditivo", "bi-flag-fill"),
            new Conquista("RODADA_PERFEITA", "Ouvido de Ouro", "Acertou todas as perguntas de uma rodada", "bi-stars"),
            new Conquista("DEZ_ACERTOS", "Afinando o Ouvido", "Somou 10 acertos no treino auditivo", "bi-bullseye"),
            new Conquista("CINQUENTA_ACERTOS", "Ouvido Treinado", "Somou 50 acertos no treino auditivo", "bi-award-fill"),
            new Conquista("XP_500", "500 XP", "Alcançou 500 pontos de experiência", "bi-lightning-charge-fill"),
            new Conquista("XP_1000", "1.000 XP", "Alcançou 1.000 pontos de experiência", "bi-lightning-charge-fill"),
            new Conquista("STREAK_3", "Constância", "Praticou 3 dias seguidos", "bi-fire"),
            new Conquista("STREAK_7", "Semana Afinada", "Praticou 7 dias seguidos", "bi-calendar-check-fill")));
    }

    private void criarUsuariosDemo() {
        String senha = encoder.encode("12345678");

        Usuario aluno = novo("Aluno Demo", "aluno@harmoniahub.com.br", senha, Plano.DEMO,
                NivelConhecimento.INICIANTE, Set.of(Instrumento.VIOLAO), 0, 0);
        usuarioRepo.save(aluno);

        Usuario juliana = novo("Juliana Silva", "juliana@harmoniahub.com.br", senha, Plano.PREMIUM,
                NivelConhecimento.INTERMEDIARIO, Set.of(Instrumento.TECLADO, Instrumento.CANTO), 1450, 12);
        juliana.setUltimaPratica(LocalDate.now());
        juliana.getConquistas().addAll(conquistaRepo.findAll());   // as 8 medalhas do protótipo
        usuarioRepo.save(juliana);

        Usuario mateus = novo("Mateus Castro", "mateus@harmoniahub.com.br", senha, Plano.PREMIUM,
                NivelConhecimento.AVANCADO, Set.of(Instrumento.VIOLAO), 3420, 20);
        Usuario ana = novo("Ana Luiza", "ana@harmoniahub.com.br", senha, Plano.PREMIUM,
                NivelConhecimento.INTERMEDIARIO, Set.of(Instrumento.CONTRABAIXO), 2980, 9);
        usuarioRepo.saveAll(List.of(mateus, ana));

        // XP de ontem para aparecer no ranking semanal
        LocalDateTime ontem = LocalDateTime.now().minusDays(1);
        for (Usuario u : List.of(juliana, mateus, ana)) {
            xpRepo.save(new HistoricoXp(u, u.getXp(), "SEED", ontem));
        }
    }

    private Usuario novo(String nome, String email, String senhaHash, Plano plano,
                         NivelConhecimento nivel, Set<Instrumento> instr, int xp, int streak) {
        Usuario u = new Usuario();
        u.setNome(nome); u.setEmail(email); u.setSenha(senhaHash);
        u.setPlano(plano); u.setNivel(nivel);
        u.setInstrumentos(new java.util.HashSet<>(instr));
        u.setXp(xp); u.setStreak(streak);
        return u;
    }
}
