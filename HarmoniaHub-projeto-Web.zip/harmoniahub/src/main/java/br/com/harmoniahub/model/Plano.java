package br.com.harmoniahub.model;

public enum Plano {
    DEMO("Demo Grátis"), PREMIUM("Premium Pro");

    private final String rotulo;
    Plano(String rotulo) { this.rotulo = rotulo; }
    public String getRotulo() { return rotulo; }
}
