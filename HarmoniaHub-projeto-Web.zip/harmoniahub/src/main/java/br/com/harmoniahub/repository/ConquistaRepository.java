package br.com.harmoniahub.repository;

import br.com.harmoniahub.model.Conquista;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConquistaRepository extends JpaRepository<Conquista, Long> {
    Optional<Conquista> findByCodigo(String codigo);
    List<Conquista> findAllByOrderByIdAsc();
}
