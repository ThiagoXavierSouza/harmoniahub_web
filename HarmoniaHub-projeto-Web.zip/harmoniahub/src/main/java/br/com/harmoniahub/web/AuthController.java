package br.com.harmoniahub.web;

import br.com.harmoniahub.dto.CadastroForm;
import br.com.harmoniahub.model.Instrumento;
import br.com.harmoniahub.model.NivelConhecimento;
import br.com.harmoniahub.service.EmailJaCadastradoException;
import br.com.harmoniahub.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/** Telas de Login (Tela 1) e Cadastro (UC001/UC002). */
@Controller
public class AuthController {

    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @ModelAttribute("niveis")
    public NivelConhecimento[] niveis() { return NivelConhecimento.values(); }

    @ModelAttribute("instrumentosDisponiveis")
    public Instrumento[] instrumentos() { return Instrumento.values(); }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/cadastro")
    public String cadastro(Model model) {
        model.addAttribute("form", new CadastroForm());
        return "cadastro";
    }

    @PostMapping("/cadastro")
    public String salvar(@Valid @ModelAttribute("form") CadastroForm form, BindingResult result) {
        if (form.getSenha() != null && !form.getSenha().equals(form.getConfirmarSenha())) {
            result.rejectValue("confirmarSenha", "senhas.diferentes", "As senhas não conferem");
        }
        if (result.hasErrors()) return "cadastro";

        try {
            usuarioService.cadastrar(form);
        } catch (EmailJaCadastradoException e) {
            result.rejectValue("email", "email.duplicado", "Este e-mail já está cadastrado");
            return "cadastro";
        }
        return "redirect:/login?cadastrado";
    }
}
