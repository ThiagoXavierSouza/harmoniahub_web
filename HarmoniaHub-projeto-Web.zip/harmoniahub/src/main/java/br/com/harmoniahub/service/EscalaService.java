package br.com.harmoniahub.service;

import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.music.GrauHarmonico;
import br.com.harmoniahub.music.ModoEscala;
import br.com.harmoniahub.music.TeoriaMusical;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Service;

/** Visualizador de escalas e campo harmônico (RF03 / UC004). */
@Service
public class EscalaService {

    public record EscalaResultado(String titulo, List<String> notas, List<String> notasPt,
                                  List<Integer> classesDeAltura, List<Integer> midis,
                                  List<GrauHarmonico> campo, int raizIndice) { }

    public List<ModoEscala> modosDisponiveis(Usuario u) {
        return Arrays.stream(ModoEscala.values()).filter(m -> u.isPremium() || !m.isPremium()).toList();
    }

    public ModoEscala modoValido(String nome, Usuario u) {
        try {
            ModoEscala m = ModoEscala.valueOf(nome);
            return (u.isPremium() || !m.isPremium()) ? m : ModoEscala.MAIOR;
        } catch (IllegalArgumentException | NullPointerException e) {
            return ModoEscala.MAIOR;
        }
    }

    public EscalaResultado montar(String raiz, ModoEscala modo) {
        int idx = TeoriaMusical.indiceNota(raiz);
        List<Integer> semitons = TeoriaMusical.semitonsDaEscala(idx, modo);

        List<String> notas = new ArrayList<>();
        List<String> notasPt = new ArrayList<>();
        List<Integer> classes = new ArrayList<>();
        List<Integer> midis = new ArrayList<>();
        for (int s : semitons) {
            notas.add(TeoriaMusical.nome(s));
            notasPt.add(TeoriaMusical.nomePt(s));
            classes.add(Math.floorMod(s, 12));
            midis.add(60 + s);
        }
        midis.add(60 + idx + 12);   // fecha a escala na oitava, para ouvir completa

        String titulo = TeoriaMusical.NOTAS[idx] + " " + modo.getRotulo();
        return new EscalaResultado(titulo, notas, notasPt, classes, midis,
                TeoriaMusical.campoHarmonico(idx, modo), idx);
    }
}
