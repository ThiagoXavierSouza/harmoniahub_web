package br.com.harmoniahub.web;

import br.com.harmoniahub.model.Plano;
import br.com.harmoniahub.service.UsuarioService;
import java.security.Principal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

/** Troca de plano. Simulado: não há cobrança real (ver guia, etapa de melhorias). */
@Controller
public class PlanoController {

    private final UsuarioService usuarioService;

    public PlanoController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/plano/premium")
    public String premium(Principal principal) {
        usuarioService.alterarPlano(principal.getName(), Plano.PREMIUM);
        return "redirect:/painel";
    }

    @PostMapping("/plano/demo")
    public String demo(Principal principal) {
        usuarioService.alterarPlano(principal.getName(), Plano.DEMO);
        return "redirect:/demo";
    }
}
