package br.com.harmoniahub.model;

public enum NivelConhecimento {
    INICIANTE("Iniciante"), INTERMEDIARIO("Intermediário"), AVANCADO("Avançado");

    private final String rotulo;
    NivelConhecimento(String rotulo) { this.rotulo = rotulo; }
    public String getRotulo() { return rotulo; }
}
