package br.com.harmoniahub.repository;

import br.com.harmoniahub.model.TipoAcorde;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoAcordeRepository extends JpaRepository<TipoAcorde, Long> {
    List<TipoAcorde> findAllByOrderByIdAsc();
    List<TipoAcorde> findByPremiumFalseOrderByIdAsc();
}
