package br.com.harmoniahub.service;

import br.com.harmoniahub.model.TipoAcorde;
import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.music.TeoriaMusical;
import br.com.harmoniahub.repository.TipoAcordeRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Dicionário e formador de acordes (RF02 / UC003). */
@Service
public class AcordeService {

    /** Resultado pronto para a tela. */
    public record AcordeResultado(Long tipoId, String raiz, String cifra, String nomeCompleto,
                                  List<String> notas, List<String> notasPt,
                                  List<String> intervalos, List<Integer> midis) { }

    private final TipoAcordeRepository tipoRepo;

    public AcordeService(TipoAcordeRepository tipoRepo) {
        this.tipoRepo = tipoRepo;
    }

    /** Demo vê só tríades gratuitas; Premium vê tudo. */
    @Transactional(readOnly = true)
    public List<TipoAcorde> tiposDisponiveis(Usuario u) {
        return u.isPremium() ? tipoRepo.findAllByOrderByIdAsc() : tipoRepo.findByPremiumFalseOrderByIdAsc();
    }

    @Transactional(readOnly = true)
    public List<TipoAcorde> tiposBloqueados(Usuario u) {
        if (u.isPremium()) return List.of();
        return tipoRepo.findAllByOrderByIdAsc().stream().filter(TipoAcorde::isPremium).toList();
    }

    /** Aceita só notas válidas; qualquer outra coisa vira "C". */
    public String raizValida(String raiz) {
        try {
            return TeoriaMusical.NOTAS[TeoriaMusical.indiceNota(raiz)];
        } catch (IllegalArgumentException | NullPointerException e) {
            return "C";
        }
    }

    public AcordeResultado formar(String raiz, TipoAcorde tipo) {
        int idx = TeoriaMusical.indiceNota(raiz);
        int base = TeoriaMusical.midiBase(idx);

        List<String> notas = new ArrayList<>();
        List<String> notasPt = new ArrayList<>();
        List<String> intervalos = new ArrayList<>();
        List<Integer> midis = new ArrayList<>();

        for (int s : tipo.getSemitons()) {
            notas.add(TeoriaMusical.nome(idx + s));
            notasPt.add(TeoriaMusical.nomePt(idx + s));
            intervalos.add(TeoriaMusical.rotuloIntervalo(s));
            midis.add(base + s);
        }
        String cifra = TeoriaMusical.NOTAS[idx] + tipo.getSufixo();
        String nomeCompleto = TeoriaMusical.NOTAS_PT[idx] + " – " + tipo.getNome();
        return new AcordeResultado(tipo.getId(), TeoriaMusical.NOTAS[idx], cifra, nomeCompleto,
                notas, notasPt, intervalos, midis);
    }

    /** Catálogo: o mesmo acorde-raiz em todas as variações liberadas. */
    public List<AcordeResultado> catalogo(String raiz, List<TipoAcorde> tipos) {
        return tipos.stream().map(t -> formar(raiz, t)).toList();
    }
}
