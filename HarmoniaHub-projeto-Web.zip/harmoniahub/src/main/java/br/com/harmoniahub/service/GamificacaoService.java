package br.com.harmoniahub.service;

import br.com.harmoniahub.model.Conquista;
import br.com.harmoniahub.model.HistoricoXp;
import br.com.harmoniahub.model.Usuario;
import br.com.harmoniahub.repository.ConquistaRepository;
import br.com.harmoniahub.repository.HistoricoXpRepository;
import br.com.harmoniahub.repository.RankingLinha;
import br.com.harmoniahub.repository.TentativaRepository;
import br.com.harmoniahub.repository.UsuarioRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** XP, sequência (streak), medalhas e ranking semanal (RF06 / UC007). */
@Service
public class GamificacaoService {

    public static final int XP_POR_ACERTO = 20;
    public static final int BONUS_RODADA_PERFEITA = 50;

    public record Resumo(int acertos, int total, int xpGanho, int xpTotal,
                         int streak, int nivel, List<String> novasMedalhas) { }

    private final UsuarioRepository usuarioRepo;
    private final HistoricoXpRepository xpRepo;
    private final TentativaRepository tentativaRepo;
    private final ConquistaRepository conquistaRepo;

    public GamificacaoService(UsuarioRepository usuarioRepo, HistoricoXpRepository xpRepo,
                              TentativaRepository tentativaRepo, ConquistaRepository conquistaRepo) {
        this.usuarioRepo = usuarioRepo;
        this.xpRepo = xpRepo;
        this.tentativaRepo = tentativaRepo;
        this.conquistaRepo = conquistaRepo;
    }

    /**
     * Chamado SÓ quando a rodada termina por inteiro na mesma sessão (RN002).
     */
    @Transactional
    public Resumo registrarRodada(Long usuarioId, int acertos, int total) {
        Usuario u = usuarioRepo.findById(usuarioId).orElseThrow();
        boolean perfeita = acertos == total;
        int xp = acertos * XP_POR_ACERTO + (perfeita ? BONUS_RODADA_PERFEITA : 0);

        u.setXp(u.getXp() + xp);
        atualizarStreak(u);
        if (xp > 0) xpRepo.save(new HistoricoXp(u, xp, "TREINO_AUDITIVO"));

        List<String> novas = avaliarConquistas(u, perfeita);
        usuarioRepo.save(u);
        return new Resumo(acertos, total, xp, u.getXp(), u.getStreak(), u.getNivelNumero(), novas);
    }

    private void atualizarStreak(Usuario u) {
        LocalDate hoje = LocalDate.now();
        LocalDate ultima = u.getUltimaPratica();
        if (ultima == null || ultima.isBefore(hoje.minusDays(1))) {
            u.setStreak(1);                       // primeira prática ou quebrou a sequência
        } else if (ultima.equals(hoje.minusDays(1))) {
            u.setStreak(u.getStreak() + 1);       // praticou ontem: continua
        }                                          // praticou hoje: não muda
        u.setUltimaPratica(hoje);
    }

    private List<String> avaliarConquistas(Usuario u, boolean rodadaPerfeita) {
        long acertos = tentativaRepo.countByUsuarioIdAndAcertouTrue(u.getId());
        Map<String, Boolean> regras = new LinkedHashMap<>();
        regras.put("PRIMEIRA_RODADA", true);
        regras.put("RODADA_PERFEITA", rodadaPerfeita);
        regras.put("DEZ_ACERTOS", acertos >= 10);
        regras.put("CINQUENTA_ACERTOS", acertos >= 50);
        regras.put("XP_500", u.getXp() >= 500);
        regras.put("XP_1000", u.getXp() >= 1000);
        regras.put("STREAK_3", u.getStreak() >= 3);
        regras.put("STREAK_7", u.getStreak() >= 7);

        List<String> novas = new ArrayList<>();
        regras.forEach((codigo, atingiu) -> {
            if (!atingiu) return;
            conquistaRepo.findByCodigo(codigo).ifPresent((Conquista c) -> {
                if (u.getConquistas().add(c)) novas.add(c.getNome());   // add() devolve false se já tinha
            });
        });
        return novas;
    }

    @Transactional(readOnly = true)
    public List<RankingLinha> rankingSemanal() {
        return xpRepo.ranking(LocalDateTime.now().minusDays(7), PageRequest.of(0, 5));
    }

    @Transactional(readOnly = true)
    public List<Conquista> todasConquistas() {
        return conquistaRepo.findAllByOrderByIdAsc();
    }
}
