/* Motor de áudio (RF05 / RNF01): Web Audio API nativa, sem bibliotecas. */
const HHAudio = (() => {
  let ctx = null;

  function garantir() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();   // navegadores exigem um clique antes do som
    return ctx;
  }

  const frequencia = midi => 440 * Math.pow(2, (midi - 69) / 12);   // A4 = MIDI 69 = 440 Hz

  /** Toca UMA nota. quando = atraso em segundos. */
  function nota(midi, duracao = 0.9, quando = 0, volume = 0.22) {
    const c = garantir();
    const t = c.currentTime + quando;
    const g = c.createGain();
    const osc = c.createOscillator();    // fundamental
    const osc2 = c.createOscillator();   // harmônico (oitava) deixa o timbre mais "cheio"
    const g2 = c.createGain();
    osc.type = 'triangle'; osc.frequency.value = frequencia(midi);
    osc2.type = 'sine';    osc2.frequency.value = frequencia(midi) * 2;
    g2.gain.value = 0.25;
    osc.connect(g); osc2.connect(g2); g2.connect(g); g.connect(c.destination);
    // envelope: ataque rápido + decaimento exponencial (evita "cliques")
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(volume, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duracao);
    osc.start(t); osc2.start(t);
    osc.stop(t + duracao + 0.05); osc2.stop(t + duracao + 0.05);
  }

  const acorde = (midis, duracao = 1.5) => midis.forEach(m => nota(m, duracao, 0, 0.15));
  const sequencia = (midis, passo = 0.5) => midis.forEach((m, i) => nota(m, passo * 1.5, i * passo));

  return { nota, acorde, sequencia, garantir };
})();

/* Qualquer elemento com data-nota / data-acorde / data-arpejo toca ao clicar. */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-nota],[data-acorde],[data-arpejo]');
  if (!el) return;
  const lista = s => s.split(',').map(Number);
  if (el.dataset.nota)   HHAudio.nota(Number(el.dataset.nota));
  if (el.dataset.acorde) HHAudio.acorde(lista(el.dataset.acorde));
  if (el.dataset.arpejo) HHAudio.sequencia(lista(el.dataset.arpejo));
});
