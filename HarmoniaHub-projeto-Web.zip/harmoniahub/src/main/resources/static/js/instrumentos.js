/* Instrumentos virtuais: piano (RF05), braço de violão (RF03) e Web MIDI (RN005). */
(() => {
  const NOMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const ehPreta = m => [1, 3, 6, 8, 10].includes(m % 12);
  const lista = s => (s || '').split(',').filter(Boolean).map(Number);

  /* ----- Piano: <div class="hh-piano" data-from="60" data-to="83" data-destaque="60,64,67"> ----- */
  function tocarTecla(m) {
    HHAudio.nota(m, 1.0);
    marcar(m);
  }
  function marcar(m) {
    document.querySelectorAll(`.hh-piano .tecla[data-midi="${m}"]`).forEach(k => {
      k.classList.add('tocando');
      setTimeout(() => k.classList.remove('tocando'), 220);
    });
  }

  function renderPiano(el) {
    const de = Number(el.dataset.from || 60), ate = Number(el.dataset.to || 83);
    const destaque = new Set(lista(el.dataset.destaque));
    const pcs = el.dataset.pcs ? new Set(lista(el.dataset.pcs)) : null;   // destaca a nota em todas as oitavas
    let brancas = 0;
    for (let m = de; m <= ate; m++) if (!ehPreta(m)) brancas++;
    const w = 100 / brancas;
    el.innerHTML = '';
    let idx = 0;
    for (let m = de; m <= ate; m++) {
      const k = document.createElement('div');
      k.dataset.midi = m;
      if (ehPreta(m)) {
        k.className = 'tecla preta';
        k.style.left = (idx * w - w * 0.3) + '%';
        k.style.width = (w * 0.6) + '%';
      } else {
        k.className = 'tecla branca';
        k.style.left = (idx * w) + '%';
        k.style.width = w + '%';
        k.innerHTML = '<span>' + NOMES[m % 12] + (m % 12 === 0 ? (Math.floor(m / 12) - 1) : '') + '</span>';
        idx++;
      }
      if (destaque.has(m) || (pcs && pcs.has(m % 12))) k.classList.add('ativa');
      k.addEventListener('mousedown', ev => { ev.preventDefault(); tocarTecla(m); });
      k.addEventListener('touchstart', ev => { ev.preventDefault(); tocarTecla(m); }, { passive: false });
      el.appendChild(k);
    }
    if (el.dataset.teclado === 'true') ligarTecladoDoComputador(Number(el.dataset.base || de));
  }

  /* Teclado do computador: A W S E D F T G Y H U J K O L P ; => notas a partir de data-base */
  function ligarTecladoDoComputador(base) {
    const mapa = { a: 0, w: 1, s: 2, e: 3, d: 4, f: 5, t: 6, g: 7, y: 8, h: 9, u: 10, j: 11, k: 12, o: 13, l: 14, p: 15, ';': 16 };
    const apertadas = new Set();
    document.addEventListener('keydown', ev => {
      if (ev.repeat || ev.ctrlKey || ev.metaKey || ev.altKey) return;
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
      const off = mapa[ev.key.toLowerCase()];
      if (off === undefined || apertadas.has(ev.key)) return;
      apertadas.add(ev.key);
      tocarTecla(base + off);
    });
    document.addEventListener('keyup', ev => apertadas.delete(ev.key));
  }

  /* ----- Braço do violão: <div class="hh-fretboard" data-pcs="0,2,4,5,7,9,11" data-raiz="0"> ----- */
  function renderBraco(el) {
    const pcs = new Set(lista(el.dataset.pcs));
    const raiz = Number(el.dataset.raiz);
    const cordas = [64, 59, 55, 50, 45, 40];     // E4 B3 G3 D3 A2 E2 (afinação padrão)
    const trastes = 13;
    let html = '<table class="hh-fret"><thead><tr>';
    for (let f = 0; f < trastes; f++) html += '<th>' + f + '</th>';
    html += '</tr></thead><tbody>';
    cordas.forEach(aberta => {
      html += '<tr>';
      for (let f = 0; f < trastes; f++) {
        const midi = aberta + f, pc = midi % 12;
        if (pcs.has(pc)) html += `<td class="${pc === raiz ? 'raiz' : 'nota'}" data-nota="${midi}" data-n="${NOMES[pc]}"></td>`;
        else html += '<td></td>';
      }
      html += '</tr>';
    });
    el.innerHTML = html + '</tbody></table>';
  }

  /* ----- Web MIDI (RN005): só liga depois que o usuário aceita a permissão do navegador ----- */
  async function conectarMidi() {
    const status = document.getElementById('midi-status');
    if (!navigator.requestMIDIAccess) {
      status.textContent = 'Seu navegador não suporta Web MIDI. Use Chrome ou Edge.';
      return;
    }
    try {
      const acesso = await navigator.requestMIDIAccess();   // abre o pedido de permissão
      const ligar = () => {
        const entradas = [...acesso.inputs.values()];
        entradas.forEach(inp => {
          inp.onmidimessage = msg => {
            const [estado, nota, velocidade] = msg.data;
            if ((estado & 0xf0) === 0x90 && velocidade > 0) {   // 0x90 = note on
              HHAudio.nota(nota, 1.0, 0, Math.max(0.05, velocidade / 127 * 0.3));
              marcar(nota);
            }
          };
        });
        status.textContent = entradas.length
          ? 'Conectado: ' + entradas.map(i => i.name).join(', ')
          : 'Permissão concedida, mas nenhum teclado USB/Bluetooth foi detectado.';
      };
      acesso.onstatechange = ligar;
      ligar();
    } catch (e) {
      status.textContent = 'Permissão negada. Libere o acesso MIDI nas configurações do navegador.';
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.hh-piano').forEach(renderPiano);
    document.querySelectorAll('.hh-fretboard').forEach(renderBraco);
    const btn = document.getElementById('btn-midi');
    if (btn) btn.addEventListener('click', conectarMidi);
  });
})();
