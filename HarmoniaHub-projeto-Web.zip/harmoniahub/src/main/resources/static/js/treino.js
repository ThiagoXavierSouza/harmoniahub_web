/* Treino auditivo (RF04): fala com /api/treino/* e toca as notas com Web Audio.
   As regras (3 audições, XP só no fim da rodada) são aplicadas no SERVIDOR. */
(() => {
  const raiz = document.getElementById('treino');
  if (!raiz) return;

  const $ = id => document.getElementById(id);
  const btnPlay = $('treino-play'), btnIniciar = $('treino-iniciar');
  const boxOpcoes = $('treino-opcoes'), status = $('treino-status');
  const progresso = $('treino-progresso'), restantesEl = $('treino-restantes'), resumoEl = $('treino-resumo');
  const MAX = Number(raiz.dataset.max || 3);

  const csrf = document.querySelector('meta[name="_csrf"]').content;
  const csrfHeader = document.querySelector('meta[name="_csrf_header"]').content;

  async function chamar(url, metodo = 'POST', corpo = null) {
    const resp = await fetch(url, {
      method: metodo,
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', [csrfHeader]: csrf },
      body: corpo ? JSON.stringify(corpo) : null
    });
    const dados = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(dados.message || 'Erro ' + resp.status);
    return dados;
  }

  function mostrarPergunta(p) {
    progresso.textContent = `Pergunta ${p.numero} de ${p.total}`;
    restantesEl.textContent = p.restantes;
    status.textContent = 'Clique em ▶ para ouvir o intervalo e escolha a resposta.';
    btnPlay.disabled = p.restantes <= 0;
    boxOpcoes.innerHTML = '';
    p.opcoes.forEach(o => {
      const b = document.createElement('button');
      b.className = 'opcao'; b.textContent = o.rotulo; b.dataset.valor = o.semitons;
      b.addEventListener('click', () => responder(o.semitons, b));
      boxOpcoes.appendChild(b);
    });
  }

  async function iniciar() {
    try {
      resumoEl.classList.add('d-none');
      btnIniciar.classList.add('d-none');
      mostrarPergunta(await chamar('/api/treino/iniciar'));
    } catch (e) { status.textContent = e.message; btnIniciar.classList.remove('d-none'); }
  }

  async function ouvir() {
    try {
      const r = await chamar('/api/treino/ouvir');
      HHAudio.sequencia(r.notas, 0.7);
      restantesEl.textContent = r.restantes;
      if (r.restantes <= 0) btnPlay.disabled = true;     // RN004
    } catch (e) { status.textContent = e.message; btnPlay.disabled = true; }
  }

  async function responder(valor, botao) {
    boxOpcoes.querySelectorAll('button').forEach(b => b.disabled = true);
    btnPlay.disabled = true;
    try {
      const r = await chamar('/api/treino/responder', 'POST', { resposta: valor });
      botao.classList.add(r.acertou ? 'certa' : 'errada');
      status.textContent = r.acertou ? '✔ Acertou! ' + r.correta : '✘ Errou. Era: ' + r.correta;
      if (r.finalizada) return setTimeout(() => finalizar(r.resumo), 1300);
      setTimeout(async () => mostrarPergunta(await chamar('/api/treino/pergunta', 'GET')), 1300);
    } catch (e) {
      status.textContent = e.message;
      boxOpcoes.querySelectorAll('button').forEach(b => b.disabled = false);
      btnPlay.disabled = false;
    }
  }

  function finalizar(r) {
    boxOpcoes.innerHTML = '';
    progresso.textContent = 'Rodada concluída!';
    status.textContent = '';
    restantesEl.textContent = MAX;
    const medalhas = r.novasMedalhas.length
      ? `<div class="mt-2 text-warning"><i class="bi bi-award-fill"></i> Nova(s) medalha(s): <b>${r.novasMedalhas.join(', ')}</b></div>` : '';
    resumoEl.innerHTML = `<div class="alert alert-hh-ok mb-0">
        <b>${r.acertos} de ${r.total} acertos</b> • <b>+${r.xpGanho} XP</b> (total: ${r.xpTotal} XP • Nível ${r.nivel} • ${r.streak} dia(s) seguidos)
        ${medalhas}</div>`;
    resumoEl.classList.remove('d-none');
    const xp = $('xp-total'); if (xp) xp.textContent = r.xpTotal.toLocaleString('pt-BR') + ' XP';
    const st = $('streak'); if (st) st.textContent = r.streak + ' Dias';
    btnIniciar.textContent = 'Nova rodada';
    btnIniciar.classList.remove('d-none');
    btnPlay.disabled = true;
  }

  btnPlay.addEventListener('click', ouvir);
  btnIniciar.addEventListener('click', iniciar);
})();
