-- Execute no MySQL Workbench / terminal antes de iniciar (opcional: a URL já usa createDatabaseIfNotExist)
CREATE DATABASE IF NOT EXISTS harmoniahub
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usuário dedicado (recomendado em vez de usar o root):
-- CREATE USER 'harmonia'@'localhost' IDENTIFIED BY 'troque_esta_senha';
-- GRANT ALL PRIVILEGES ON harmoniahub.* TO 'harmonia'@'localhost';
-- FLUSH PRIVILEGES;
